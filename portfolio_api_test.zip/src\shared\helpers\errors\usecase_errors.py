from src.shared.helpers.errors.base_error import BaseError

class NoItemsFound(BaseError):
    def __init__(self, message: str):
        super().__init__(f'No items found for {message}')

class DuplicatedItem(BaseError):
    def __init__(self, message: str):
        super().__init__(f'The item alredy exists for this {message}')

class NoUsersFound(BaseError):
    def __init__(self, message: str):
        super().__init__(f'No users found for {message}')

class DuplicatedUser(BaseError):
    def __init__(self, message: str):
        super().__init__(f'The user already exists for this {message}')

class ForbiddenAction(BaseError):
    def __init__(self, message: str):
        super().__init__(f'That action is forbidden for this {message}')

class InvalidJwtFormat(BaseError):
    def __init__(self, message: str = "jwt"):
        super().__init__(f'Invalid JWT format for {message}')

class EnvVarNotFound(BaseError):
    def __init__(self, message: str):
        super().__init__(f'Environment variable {message} not found')

